
# Survinng

<!-- badges: start -->
<!-- badges: end -->

The goal of Survinng is to ...

## Installation

You can install the development version of Survinng like so:

``` r
# FILL THIS IN! HOW CAN PEOPLE INSTALL YOUR DEV PACKAGE?
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(Survinng)
## basic example code
```

