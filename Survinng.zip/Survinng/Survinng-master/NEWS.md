# Survinng (development version)

* Initial CRAN submission.
