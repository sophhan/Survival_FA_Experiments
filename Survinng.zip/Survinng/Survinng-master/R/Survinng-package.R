#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @import ggplot2
#' @import checkmate
#' @importFrom utils combn
#' @importFrom dplyr %>% arrange group_by summarize mutate coalesce lag
#' @importFrom methods setClass new setGeneric setMethod
#' @importFrom stats rnorm runif sd
## usethis namespace: end
NULL
